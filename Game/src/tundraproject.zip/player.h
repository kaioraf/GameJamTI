#include "defines.h"
#include "sprite.h"
#pragma once

class Player : public Sprite
{
private:
    /* data */
public:
    bool isDead;
    int score;
    gfx_sprite_t *flippedForeground;
    Player(gfx_sprite_t *Foreground, gfx_sprite_t *FlippedForeground, int startX, int startY, int spriteWidth, int spriteHeight);
    void InitialiseFlippedSprite(gfx_sprite_t *FlippedForeground);
    void FlipSprite();
    void drawSpriteIndicator(Sprite* IndicatedSprite);
    void update();
    ~Player();
};