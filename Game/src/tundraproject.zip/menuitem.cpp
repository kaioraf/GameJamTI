#include "menuitem.h"

menuItem::menuItem(int ID, const char *text)
{
    id = ID;
    itemText = text;
}

menuItem::~menuItem()
{
}
