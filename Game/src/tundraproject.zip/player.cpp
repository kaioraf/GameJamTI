#include "player.h"

Player::Player(gfx_sprite_t *Foreground, gfx_sprite_t *FlippedForeground, int startX, int startY, int spriteWidth, int spriteHeight)
{
    Sprite(Foreground, startX, startY, spriteWidth, spriteHeight);
    InitialiseFlippedSprite(FlippedForeground);
    isDead = false;
    score = 0;
}

// Draws an indicator around the player to show the direction of another sprite (enemy)
void Player::drawSpriteIndicator(Sprite* IndicatedSprite)
{
    float alpha = calculateAngleBetween(IndicatedSprite);

    float dX = cos(alpha) * 16;
    float dY = sin(alpha) * 16;
    int circleXPos = this->x + (this->width / 2) + dX;
    int circleYpos = this->y + (this->height / 2) + dY;
    gfx_SetColor(34);
    gfx_FillCircle(circleXPos, circleYpos, 2);
    gfx_SetColor(32);
    gfx_Circle(circleXPos, circleYpos, 2);
}


void Player::InitialiseFlippedSprite(gfx_sprite_t *FlippedForeground)
{
    isFlipped = false;
    flippedForeground = FlippedForeground;
    gfx_FlipSpriteY(foreground, flippedForeground);
}

void Player::FlipSprite()
{
    gfx_sprite_t *oldForeground = foreground;
    foreground = flippedForeground;
    flippedForeground = oldForeground;
    isFlipped = !isFlipped;
}

void Player::update()
{
    Animate();
    Draw();
}

Player::~Player()
{
}