#include "defines.h"
#include "player.h"
#include "tilemap.h"
#include "enemy.h"
#include "vector/vector.h"

bool tilemapShouldMove(char direction, Tilemap *currentLevel, Player *Player);

void movementInput(kb_key_t arrows, kb_key_t controlButtons, Tilemap *currentLevel, Player *Player, Vector<Enemy> enemies); // arrows declared in setup

//TODO void weapooninput
