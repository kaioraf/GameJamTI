#include "tilemap.h"

Tilemap::Tilemap(unsigned char currentTileMap[], gfx_sprite_t **tilesetTiles, uint8_t tileType, uint8_t tileSize, uint8_t drawWidth, uint8_t drawHeight, uint8_t tilemapHeight, uint16_t tilemapWidth, uint8_t xOffset, uint8_t yOffset, int tilemapId)
{
    Animated(xOffset, yOffset, false);
    tilemap.map = currentTileMap;
    tilemap.tiles = tilesetTiles;
    tilemap.type_width = tileType;
    tilemap.type_height = tileType;
    tilemap.tile_height = tileSize;
    tilemap.tile_width = tileSize;
    tilemap.draw_height = drawHeight; 
    tilemap.draw_width = drawWidth;
    tilemap.height = tilemapHeight;
    tilemap.width = tilemapWidth;
    tilemap.x_loc = xOffset;
    tilemap.y_loc = yOffset;
    tilemapID = tilemapId;
}

//gets the tile id of given x and y positions with tilemap x and y offsets
int Tilemap::ConvertPosition(int x, int y)
{
    int tileAtSpritePos = gfx_GetTile(&this->tilemap, this->x + x - snowLevel1_X_OFFSET, this->y + y - snowLevel1_Y_OFFSET); 
    return tileAtSpritePos;
}

bool Tilemap::isWalkable(int tileID) //returns based on the iswalkable.h file that has function pointers
{
    bool (*isWalkablePtr[1])(int tileID) = {snowLevel_1isWalkable};
    return (*isWalkablePtr[tilemapID])(tileID);
}

void Tilemap::update()
{
    // Animate();
    gfx_Tilemap(&tilemap, x, y);
}

Tilemap::~Tilemap()
{
}
