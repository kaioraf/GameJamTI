#include "defines.h"
#include "player.h"
#include "enemy.h"
#include "tilemap.h"
#include "vector/vector.h"

void updateAll(Tilemap *snowLevel_1, Player *player, Tilemap *Sword/* , Vector<Enemy> enemies */);