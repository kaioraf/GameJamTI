#include "defines.h"
#include "animated.h"
#include "iswalkable.h"
#pragma once

class Tilemap : public Animated
{
public:
    gfx_tilemap_t tilemap;
    Tilemap(unsigned char currentTileMap[], gfx_sprite_t **tilesetTiles, uint8_t tileType, uint8_t tileSize, uint8_t drawWidth, uint8_t drawHeight, uint8_t tilemapHeight, uint16_t tilemapWidth, uint8_t xOffset, uint8_t yOffset, int tilemapId);
    int tilemapID;
    bool isWalkable(int tileID);
    int ConvertPosition(int x, int y);
    void update();
    ~Tilemap();
};
