#include <defines.h>
#include "menu.h"
#include "player.h"
#include "enemy.h"
#include "tilemap.h"
#include "gameRunner.h"
#include "vector/vector.h"
#include "update.h"
/*create an uninitialised sprite for the player when flipped */
gfx_UninitedSprite(flippedPlayer, PlayerSprite_width, PlayerSprite_height);

// initialise classes
// run game seperate file
// handle game shutdown

void GraphxSetup()
{
    gfx_Begin();
    gfx_SetClipRegion(0, 16, 320, 240);
    /* Set the palette */
    gfx_SetPalette(global_palette, sizeof_global_palette, 0);
    gfx_SetColor(64);
    gfx_SetTextFGColor(1);
    gfx_SetTextBGColor(0);

    /* Draw to buffer to avoid tearing */
    gfx_SetDrawBuffer();
    return;
}

int main()
{
    GraphxSetup();
    Tilemap *snowLevel_1 = new Tilemap(snowLevel_1_map, snowSet1_tiles, gfx_tile_16_pixel, TILE_HEIGHT, snowLevel1_DRAW_WIDTH, snowLevel1_DRAW_HEIGHT, snowLevel1_HEIGHT, snowLevel1_WIDTH, snowLevel1_X_OFFSET, snowLevel1_Y_OFFSET, 0);
    snowLevel_1->update();
    // Tilemap *sword = new Tilemap(sword_map, SwordMap_tiles, gfx_tile_no_pow2, swordTile_HEIGHT, sword_DRAW_WIDTH, sword_DRAW_HEIGHT, sword_HEIGHT, sword_WIDTH, sword_X_OFFSET, sword_Y_OFFSET, 0);
    // sword->animationSteps = swordTile_WIDTH;
    
    // int startXLocation = rand() % (TILE_HEIGHT * snowLevel1_WIDTH);
    // int startYLocation = rand() % (TILE_WIDTH * snowLevel1_HEIGHT);
    // Enemy *Knight = new Enemy(knightEnemy, startXLocation, startYLocation, knightEnemy_width, knightEnemy_height, clock(), false);
    // Player *player = new Player(PlayerSprite, flippedPlayer, PLAYER_START_X, PLAYER_START_Y, PlayerSprite_width, PlayerSprite_height);
    // Tilemap *mainMenuTilemap = new Tilemap(mainMenu_map, GUI_tiles, gfx_tile_16_pixel, TILE_HEIGHT, mainMenu_DRAW_WIDTH, mainMenu_DRAW_HEIGHT, mainMenu_HEIGHT, mainMenu_WIDTH, mainMenu_X_OFFSET, mainMenu_Y_OFFSET, 0);
    // Tilemap *optionsMenuTilemap = new Tilemap(mainMenu_map, GUI_tiles, gfx_tile_16_pixel, TILE_HEIGHT, mainMenu_DRAW_WIDTH, mainMenu_DRAW_HEIGHT, mainMenu_HEIGHT, mainMenu_WIDTH, optionsMenu_X_OFFSET, optionsMenu_Y_OFFSET, 0);
    // menuItem *menuContinue = new menuItem(0, "Continue");
    // menuItem *menuOptions = new menuItem(1, "Options");
    // menuItem *menuClosegame = new menuItem(2, "Close game");

    // int mainMenuSize = 3;
    // menuItem *mainMenuItems[3] = {menuContinue, menuOptions, menuClosegame};
    // int mainMenuSelectedItem = 1;
    // Menu *mainMenu = new Menu(mainMenuTilemap, mainMenuSize, mainMenuItems, mainMenuSelectedItem);

    // int optionsMenuSize = 1;
    // menuItem *optionsMenuItems[1] = {menuContinue};
    // int optionsSelectedItem = 1;
    // Menu *optionsMenu = new Menu(optionsMenuTilemap, optionsMenuSize, optionsMenuItems, optionsSelectedItem);

    // int gameOverSize = 1;
    // menuItem *gameOverItems[1] = {menuClosegame};
    // int gameOverSelectedItem = 1;
    // Menu *gameOverMenu = new Menu(optionsMenuTilemap, gameOverSize, gameOverItems, gameOverSelectedItem);

    // Vector<Enemy> enemies(1);
    // enemies.pushBack(*Knight);
    
    // updateAll(snowLevel_1, player, sword, enemies);

    do
    {
        gfx_SwapDraw();
    } while (true);
    
    // runGame(player
    //         , snowLevel_1
    //         , sword
    //         // , enemies
    //         , mainMenu
    //         , optionsMenu
    //         , gameOverMenu
    //         );
    /* code */
    // delete player;
    // delete snowLevel_1;
    // delete sword;
    // delete Knight;
    // delete mainMenuTilemap;
    // delete optionsMenuTilemap;
    // delete menuContinue;
    // delete menuClosegame;
    // delete menuOptions;
    // delete mainMenu;
    // delete optionsMenu;
    // delete gameOverMenu;
    gfx_End();
    return 0;
}
