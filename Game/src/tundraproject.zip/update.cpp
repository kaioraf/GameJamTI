#include "update.h"


void updateAll(Tilemap *snowLevel_1, Player *player, Tilemap *Sword/* , Vector<Enemy> enemies */)
{
    snowLevel_1->update();
    // for (int i = 0; i < enemies.size(); i++) enemies.at(i).update(player, snowLevel_1);
    player->update();

    // TODO: please make weapon class
    // Sword->Animate();
    // if (Sword->isMoving)
    // {
    //     for (int i = 0; i < enemies.size(); i++)
    //     {
    //         if (enemies.at(i).TouchingSword(player, player->isFlipped))
    //         {
    //             enemies.at(i).Respawn(snowLevel_1);
    //         } 
    //     }
    //     gfx_TransparentTilemap(&Sword->tilemap, Sword->x, Sword->y);
    // }
    gfx_SwapDraw();
}