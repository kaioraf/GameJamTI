#include "gameRunner.h"

void runGame(Player *player
            , Tilemap *snowLevel_1
            , Tilemap *Sword
            // , Vector<Enemy> enemies
            , Menu *mainMenu
            , Menu *optionsMenu
            , Menu *gameOverMenu)
{
    clock_t clockTime = clock();
    clock_t lastUpdate = 0;
    clock_t timeSinceLastUpdate;
    srand(time(NULL));
    rand();
    bool stopGame = false;
    bool menuOpen = false;
    kb_key_t arrows;
    kb_key_t controlButtons;
    Menu *currentMenu;
    currentMenu = mainMenu;
    do
    {
        clockTime = clock();
        timeSinceLastUpdate = clockTime - lastUpdate;

        kb_Scan();
        arrows = kb_Data[7];
        controlButtons = kb_Data[1];
        // currentTile = ConvertSpritePosition(snowLevel_1, player->x, player->y);

        // if (timeSinceLastUpdate > 1092) // update 30 times per second
        {
            // if (!Knight->isMoving) Knight->Move(snowLevel_1); //TODO

            // movementInput(arrows, controlButtons, snowLevel_1, player, enemies);
            updateAll(snowLevel_1, player, Sword/* , enemies */);
            lastUpdate = clockTime;
            // if (player->isDead)
            // {
            //     currentMenu = gameOverMenu;
            //     menuOpen = true;
            //     gfx_BlitBuffer();
            // }
            // if (os_GetCSC() == sk_Mode)
            // {
            //     menuOpen = true;
            //     currentMenu = mainMenu;
            //     gfx_BlitBuffer();
            // }
            // while (menuOpen)
            // {
            //     switch (currentMenu)
            //     {
            //     case 0:
            //         if (player->isDead) // don't exit gameover menu
            //         {
            //             break;
            //         }
            //         menuOpen = false;
            //         break;
            //     case 1:
            //         currentMenu = optionsMenu;
            //         break;
            //     case 2:
            //         stopGame = true;
            //         menuOpen = false;
            //         break;
            //     default:
            //         break;
            //     }
            //     menuUpdate(currentMenu);
            // }
        }
    } while (!kb_IsDown(kb_KeyEnter) || !stopGame);
    return;
}
