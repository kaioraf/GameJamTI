#include "defines.h"
#include "animated.h"

class Weapon : public Animated
{
private:
    /* data */
public:
//tilemap
//hitbox
//inherits animated class functions
    Weapon(/* args */);
    ~Weapon();
};

Weapon::Weapon(/* args */)
{
}

Weapon::~Weapon()
{
}


