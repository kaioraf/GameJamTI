#include "defines.h"
#include "menu.h"
#include "player.h"
#include "enemy.h"
#include "update.h"
#include "input.h"
#include "vector/vector.h"


void runGame(Player *player
            , Tilemap *snowLevel_1
            , Tilemap *Sword
            // , Vector<Enemy> enemies
            , Menu *mainMenu
            , Menu *optionsMenu
            , Menu *gameOverMenu);
