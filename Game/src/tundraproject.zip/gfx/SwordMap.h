#ifndef SwordMap_include_file
#define SwordMap_include_file

#ifdef __cplusplus
extern "C" {
#endif

extern unsigned char SwordMap_tile_0_data[731];
#define SwordMap_tile_0 ((gfx_sprite_t*)SwordMap_tile_0_data)
extern unsigned char SwordMap_tile_1_data[731];
#define SwordMap_tile_1 ((gfx_sprite_t*)SwordMap_tile_1_data)
extern unsigned char SwordMap_tile_2_data[731];
#define SwordMap_tile_2 ((gfx_sprite_t*)SwordMap_tile_2_data)
extern unsigned char SwordMap_tile_3_data[731];
#define SwordMap_tile_3 ((gfx_sprite_t*)SwordMap_tile_3_data)
extern unsigned char SwordMap_tile_4_data[731];
#define SwordMap_tile_4 ((gfx_sprite_t*)SwordMap_tile_4_data)
extern unsigned char SwordMap_tile_5_data[731];
#define SwordMap_tile_5 ((gfx_sprite_t*)SwordMap_tile_5_data)
extern unsigned char SwordMap_tile_6_data[731];
#define SwordMap_tile_6 ((gfx_sprite_t*)SwordMap_tile_6_data)
extern unsigned char SwordMap_tile_7_data[731];
#define SwordMap_tile_7 ((gfx_sprite_t*)SwordMap_tile_7_data)
extern unsigned char SwordMap_tile_8_data[731];
#define SwordMap_tile_8 ((gfx_sprite_t*)SwordMap_tile_8_data)
extern unsigned char SwordMap_tile_9_data[731];
#define SwordMap_tile_9 ((gfx_sprite_t*)SwordMap_tile_9_data)
extern unsigned char SwordMap_tile_10_data[731];
#define SwordMap_tile_10 ((gfx_sprite_t*)SwordMap_tile_10_data)
extern unsigned char SwordMap_tile_11_data[731];
#define SwordMap_tile_11 ((gfx_sprite_t*)SwordMap_tile_11_data)
#define SwordMap_num_tiles 12
extern unsigned char *SwordMap_tiles_data[12];
#define SwordMap_tiles ((gfx_sprite_t**)SwordMap_tiles_data)

#ifdef __cplusplus
}
#endif

#endif
