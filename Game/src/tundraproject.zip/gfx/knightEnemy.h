#ifndef knightEnemy_include_file
#define knightEnemy_include_file

#ifdef __cplusplus
extern "C" {
#endif

#define knightEnemy_width 13
#define knightEnemy_height 19
#define knightEnemy_size 249
#define knightEnemy ((gfx_sprite_t*)knightEnemy_data)
extern unsigned char knightEnemy_data[249];

#ifdef __cplusplus
}
#endif

#endif
