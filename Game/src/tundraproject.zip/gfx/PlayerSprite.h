#ifndef PlayerSprite_include_file
#define PlayerSprite_include_file

#ifdef __cplusplus
extern "C" {
#endif

#define PlayerSprite_width 16
#define PlayerSprite_height 15
#define PlayerSprite_size 242
#define PlayerSprite ((gfx_sprite_t*)PlayerSprite_data)
extern unsigned char PlayerSprite_data[242];

#ifdef __cplusplus
}
#endif

#endif
