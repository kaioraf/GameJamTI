#pragma once

bool snowLevel_1isWalkable(int tileID);