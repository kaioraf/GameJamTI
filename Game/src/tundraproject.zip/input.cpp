#include "input.h"

bool tilemapShouldMove(char direction, Tilemap *currentLevel, Player *Player)
{
    bool playerCentred;
    int tilemapLimit;
    switch (direction)
    {
        case 'd':
            playerCentred = PLAYER_START_Y == Player->x;
            if (!playerCentred) return false;
            tilemapLimit = (currentLevel->tilemap.height * TILE_HEIGHT) - ((currentLevel->tilemap.draw_height - 1) * TILE_HEIGHT);
            break;
        case 'u':
            playerCentred = PLAYER_START_Y == Player->y;
            if (!playerCentred) return false;
            tilemapLimit = 0;
            break;
        case 'r':
            playerCentred = PLAYER_START_X == Player->x;
            if (!playerCentred) return false;
            tilemapLimit = (currentLevel->tilemap.width * TILE_WIDTH) - ((currentLevel->tilemap.draw_width - 1) * TILE_WIDTH);
            break;
        case 'l':
            playerCentred = PLAYER_START_X == Player->x;
            if (!playerCentred) return false;
            tilemapLimit = 0;
            break;
        default:
            break;
    }

    if (direction == 'd' && currentLevel->x < tilemapLimit)
    {
        return true;
    }
    else if (direction == 'u' && currentLevel->x > tilemapLimit)
    {
        return true;
    }
    else if (direction == 'r' && currentLevel->y < tilemapLimit)
    {
        return true;
    }
    else if (direction == 'l' && currentLevel->y > tilemapLimit)
    {
        return true;
    }
    return false;
}

void movementInput(kb_key_t arrows, kb_key_t controlButtons, Tilemap *currentLevel, Player *Player, Vector<Enemy> enemies) // arrows declared in setup
{
    bool animatingTilemap = false;
    int tileToWalkTo;
    int movementX, movementY;
    if (arrows && !currentLevel->isMoving && !Player->isMoving)
    {
        if (arrows & kb_Down)
        {
            movementX = 0;
            movementY = 16;
            tileToWalkTo = currentLevel->ConvertPosition(Player->x + movementX, Player->y + movementY);
            if (currentLevel->isWalkable(tileToWalkTo)) return;
            animatingTilemap = tilemapShouldMove('d', currentLevel, Player);
        }
        else if (arrows & kb_Up)
        {
            movementX = 0;
            movementY = -16;
            tileToWalkTo = currentLevel->ConvertPosition(Player->x + movementX, Player->y + movementY);
            if (currentLevel->isWalkable(tileToWalkTo)) return;
            animatingTilemap = tilemapShouldMove('u', currentLevel, Player);
        }
        else if (arrows & kb_Right)
        {
            movementX = 16;
            movementY = 0;
            tileToWalkTo = currentLevel->ConvertPosition(Player->x + movementX, Player->y + movementY);
            if (currentLevel->isWalkable(tileToWalkTo)) return;
            animatingTilemap = tilemapShouldMove('r', currentLevel, Player);
        }
        else if (arrows & kb_Left)
        {
            movementX = -16;
            movementY = 0;
            tileToWalkTo = currentLevel->ConvertPosition(Player->x + movementX, Player->y + movementY);
            if (currentLevel->isWalkable(tileToWalkTo)) return;
            animatingTilemap = tilemapShouldMove('l', currentLevel, Player);
        }
        if (animatingTilemap)
        {
            for (int i = 0; i < enemies.size(); i++)
            {
                enemies.at(i).MoveDestination(-movementX, -movementY);
            }
            currentLevel->MoveDestination(movementX, movementY);
        }
        else
        {
            Player->MoveDestination(movementX, movementY);
        }
        
    }
}

//TODO void weapooninput
